package DefiningClasses_exam;

public class Children {
    private String name;
    private String birthdate;

    public Children(String name, String birthdate) {
        this.name = name;
        this.birthdate = birthdate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        if(getName() == null){
            return "";
        }
        return String.format("%s %s\n",name,birthdate);
    }
}
