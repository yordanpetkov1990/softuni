package DefiningClasses_exam;


import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private Company company;
    private Car car;
    private List<Parent> parentList;
    private List<Children> childrenList;
    private List<Pokemon> pokemonsList;

    public Person(String name) {
        this.name = name;
        this.parentList = new ArrayList<>();
        this.childrenList = new ArrayList<>();
        this.pokemonsList = new ArrayList<>();
        this.company = new Company();
        this.car = new Car();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public List<Parent> getParentList() {
        return parentList;
    }

    public void setParentList(List<Parent> parentList) {
        this.parentList = parentList;
    }

    public List<Children> getChildrenList() {
        return childrenList;
    }

    public void setChildrenList(List<Children> childrenList) {
        this.childrenList = childrenList;
    }

    public List<Pokemon> getPokemonsList() {
        return pokemonsList;
    }

    public void setPokemonsList(List<Pokemon> pokemonsList) {
        this.pokemonsList = pokemonsList;
    }

    @Override
    public String toString() {
        return String.format("%s\n" +
                "Company:\n%s" +
                "Car:\n%s" +
                "Pokemon:\n%s" +
                "Parents:\n%s" +
                "Children:\n%s",getName(),getCompany().toString(),getCar(),getPokemonsList().toString()
                .replace("[","").replace(", ","")
                .replace("]",""),getParentList().toString()
                .replace("[","")
                .replace("]","").replace(", ",""),getChildrenList().toString()
                .replace("[","").replace("]","").replace(", ",""));

    }
}
