package DefiningClasses_exam;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command = scan.nextLine();
        Map<String,Person> personMap = new HashMap<>();

        while(!"End".equals(command)){
            String[] tokens = command.split("\\s+");
            String name = tokens[0];
            String type = tokens[1];
            Person person;
            if(!personMap.containsKey(name)){
                person =new Person(name);
                personMap.put(name,person);
            }else{
                person = personMap.get(name);
            }
            switch (type){
                case "company":
                    person.setCompany(new Company(tokens[2],tokens[3],Double.parseDouble(tokens[4])));
                    break;
                case "pokemon":
                    person.getPokemonsList().add(new Pokemon(tokens[2],tokens[3]));
                    break;
                case "parents":
                    person.getParentList().add(new Parent(tokens[2],tokens[3]));
                    break;
                case "children":
                    person.getChildrenList().add(new Children(tokens[2],tokens[3]));
                    break;
                case "car":
                    person.setCar(new Car(tokens[2],Integer.parseInt(tokens[3])));
                    break;
            }



            command = scan.nextLine();
        }
        String nameToFind = scan.nextLine();
        if(personMap.containsKey(nameToFind)){
            Person person = personMap.get(nameToFind);
            System.out.println(person);
        }
    }

}
