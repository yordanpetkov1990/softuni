package Generics_exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box<Double>> boxList = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            Box<Double> doubleBox = new Box<>(Double.parseDouble(scanner.nextLine()));
            boxList.add(doubleBox);
        }
        Box<Double> newBox = new Box<>(Double.parseDouble(scanner.nextLine()));
        System.out.println(count(boxList, newBox));
//        int[] ints = Arrays.stream(scanner.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
//        swap(boxList,ints[0],ints[1]);
//        boxList.forEach(e -> System.out.println(e.toString()));

    }
    public static <T extends Comparable<T>> void swap(List<Box<T>> boxList, int firstIndex, int secondIndex){
        Box<T> tBox1 = boxList.get(firstIndex);
        Box<T> tBox2 = boxList.get(secondIndex);
        boxList.set(firstIndex,tBox2);
        boxList.set(secondIndex,tBox1);
    }
    public static <T extends Comparable<T>> int count(List<Box<T>> boxList,Box<T> element){
        int count = 0;
        for (Box<T> tBox : boxList) {
            if(tBox.compareTo(element) > 0){
                count++;
            }
        }

        return count;
    }
}
