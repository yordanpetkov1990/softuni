package Generics_exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        List<Box<Integer>> boxList = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            Box<Integer> integerBox = new Box<>(Integer.parseInt(scanner.nextLine()));
            boxList.add(integerBox);
        }
        int[] ints = Arrays.stream(scanner.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
        swap(boxList,ints[0],ints[1]);
        boxList.forEach(e -> System.out.println(e.toString()));
    }
    public static <T> void swap(List<Box<T>> boxList,int firstIndex,int secondIndex){
        Box<T> tBox1 = boxList.get(firstIndex);
        Box<T> tBox2 = boxList.get(secondIndex);
        boxList.set(firstIndex,tBox2);
        boxList.set(secondIndex,tBox1);
    }
}
