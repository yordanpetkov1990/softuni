package IteratorsAndComparators;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command = scan.nextLine();
        StackIterator stackIterator = new StackIterator();
        while(!"END".equals(command)){
            if(command.contains("Push")){
                String[] tokens = command.split(", ");
                tokens[0] = tokens[0].replace(tokens[0].substring(0,5),"");
                Integer[] integers = Arrays.stream(tokens).map(Integer::parseInt).toArray(Integer[]::new);

                stackIterator.push(integers);

            }else{
            stackIterator.pop();
            }


            command = scan.nextLine();
        }
        stackIterator.forEach(System.out::println);
        stackIterator.forEach(System.out::println);
    }
}
