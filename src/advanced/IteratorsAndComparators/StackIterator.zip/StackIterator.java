package IteratorsAndComparators;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class StackIterator implements Iterable<Integer> {
    private List<Integer> list;

    public StackIterator(List<Integer> list) {
        this.list = list;
    }

    public StackIterator() {
        this.list = new ArrayList<>();
    }
    public void push(Integer... elements){
        list.addAll(List.of(elements));
    }
    public int pop(){
        if(list.isEmpty()){
            System.out.println("No elements");
            return -1;
        }
        return list.remove(list.size() -1);
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            int index = list.size()-1;
            @Override
            public boolean hasNext() {
                return index >= 0;
            }

            @Override
            public Integer next() {
                return list.get(index--);
            }
        };
    }
}
