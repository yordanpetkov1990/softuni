package IteratorsAndComparators;



import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Lake implements Iterable<Integer> {
    private List<Integer> data;
    public Lake(){
        this.data = new ArrayList<>();
    }

    public List<Integer> getData() {
        return data;
    }

    public void setData(List<Integer> data) {
        this.data = data;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Frog();
    }

     class Frog implements Iterator<Integer>{
        int evenIndex = 0;
        int oddIndex = 1;
        int counter = 0;
         private int getIndex() {
             int times = (int)Math.ceil((double) data.size() / 2);
             int index;
             while (counter != times){
                 index = evenIndex;

                 counter++;
                 evenIndex+=2;
                 return index;
             }
             index = oddIndex;
             oddIndex+=2;
             return index;

         }
        @Override
        public boolean hasNext() {
            return evenIndex <= data.size()-1 || oddIndex <= data.size()-1;
        }

        @Override
        public Integer next() {
            return data.get(getIndex());
        }


     }

}
