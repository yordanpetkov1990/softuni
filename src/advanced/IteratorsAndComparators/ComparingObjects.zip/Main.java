package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String commnand = scan.nextLine();
        List<Person> personList = new ArrayList<>();
        while(!"END".equals(commnand)){
            String[] tokens = commnand.split("\\s+");
            String name = tokens[0];
            int age = Integer.parseInt(tokens[1]);
            String town = tokens[2];
            Person person = new Person(name,age,town);
            personList.add(person);
            commnand = scan.nextLine();
        }
        int n  = Integer.parseInt(scan.nextLine());
        Person person = personList.get(n-1);
        int equal = 0;
        personList.remove(person);
        for (Person person1 : personList) {
            int result = person1.compareTo(person);
            if(result == 0){
                equal++;
            }
        }
        if(equal == 0){
            System.out.println("No matches");
        }else{
            System.out.printf("%d %d %d\n",equal+1,personList.size()-equal,personList.size()+1);
        }

    }
}
