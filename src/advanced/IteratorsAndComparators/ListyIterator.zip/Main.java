package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command = scan.nextLine();
        ListyIterator listyIterator = new ListyIterator<>();
        while (!command.equals("END")){
            if(command.contains("Create")){
                String[] strings = Arrays.stream(command.split("\\s+")).skip(1).toArray(String[]::new);
                 listyIterator = new ListyIterator<>(strings);
            } else if (command.contains("Move")) {
                System.out.println(listyIterator.move());
            }else if(command.contains("Print")){
                try{
                    listyIterator.print();
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }

            }else if(command.equals("HasNext")){
                System.out.println(listyIterator.hasNext());
            }

            command = scan.nextLine();
        }

    }
}
