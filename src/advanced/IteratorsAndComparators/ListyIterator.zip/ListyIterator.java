package IteratorsAndComparators;

import java.util.ArrayList;
import java.util.List;

public class ListyIterator<T> {
    private static int internalIndex = 0;
    private List<T> list;


    public ListyIterator(T... elements) {
        this.list = List.of(elements);
    }
    public ListyIterator(){

    }
    public boolean move(){
        if(hasNext()){
            internalIndex++;
            return true;
        }
        return false;
    }
    public boolean hasNext(){
        return internalIndex <list.size()-1;
    }
    public void print(){
        if(list.isEmpty()){
            throw new IllegalStateException("Invalid Operation!");
        }
        System.out.println(list.get(internalIndex));
    }


    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
