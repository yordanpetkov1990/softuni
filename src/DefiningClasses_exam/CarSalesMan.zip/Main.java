package DefiningClasses_exam;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan =new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        List<Engine> engineList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] tokens = scan.nextLine().split("\\s+");
            String model = tokens[0];
            String power = tokens[1];
            Engine engine;
            if(tokens.length == 4){
                int displacement = Integer.parseInt(tokens[2]);
                String efficiency = tokens[3];
                engine = new Engine(model,power,displacement,efficiency);
            }else if(tokens.length == 3){
                if(tokens[2].matches("[0-9]+")){
                    engine = new Engine(model,power,Integer.parseInt(tokens[2]));
                }else{
                    engine = new Engine(model,power,tokens[2]);
                }
            }else{
                engine = new Engine(model,power);
            }
            engineList.add(engine);
            

        }
        int m = Integer.parseInt(scan.nextLine());
        List<Car> carList = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            String[] tokens = scan.nextLine().split("\\s+");
            String model = tokens[0];
            String engineModel = tokens[1];
            Car car;
            Engine engine = null;
            for (Engine engine1 : engineList) {
                if(engine1.getModel().equals(engineModel)){
                    engine = engine1;
                    break;
                }
            }
            if(tokens.length == 4){
                int weight = Integer.parseInt(tokens[2]);
                String color = tokens[3];
                car = new Car(model,engine,weight,color);
            }else if(tokens.length == 3){
                if(tokens[2].matches("[0-9]+")){
                    car = new Car(model,engine,Integer.parseInt(tokens[2]));
                }else{
                    car = new Car(model,engine,tokens[2]);
                }
            }else{
                car = new Car(model,engine);
            }
            carList.add(car);

        }
        carList.forEach(car -> System.out.println(car.toString()));

    }
}
