package DefiningClasses_exam;

public class Engine {
    private String model;
    private String  power;
    private int displacement;
    private String efficiency;
    public Engine(String model, String  power){
        this(model,power,-1,"n/a");
    }
    public Engine(String model, String  power,int displacement){
        this(model,power,displacement,"n/a");
    }
    public Engine(String model,String power,String efficiency){
        this(model,power,-1,efficiency);
    }


    public Engine(String model, String  power, int displacement, String efficiency) {
        this.model = model;
        this.power = power;
        this.displacement = displacement;
        this.efficiency = efficiency;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public int getDisplacement() {
        return displacement;
    }

    public void setDisplacement(int displacement) {
        this.displacement = displacement;
    }

    public String getEfficiency() {
        return efficiency;
    }

    public void setEfficiency(String efficiency) {
        this.efficiency = efficiency;
    }

    @Override
    public String toString() {
        String newDisplacament = String.valueOf(displacement);
        if(displacement == -1){
            newDisplacament = "n/a";
        }
        return String.format("%s:\nPower: %s\nDisplacement: %s\nEfficiency: %s\n",this.model,this.power,newDisplacament,this.efficiency);
    }
}
