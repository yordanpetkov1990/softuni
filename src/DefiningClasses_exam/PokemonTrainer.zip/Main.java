package DefiningClasses_exam;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String command = scan.nextLine();
        Map<String,Trainer> trainerMap = new LinkedHashMap<>();
        while (!"Tournament".equals(command)){
            String[] tokens = command.split("\\s+");
            if(tokens.length == 4) {
                //"{TrainerName} {PokemonName} {PokemonElement} {PokemonHealth}"
                String trainerName = tokens[0];
                String pokemonName = tokens[1];
                String pokemonElement = tokens[2];
                int pokemonHealth = Integer.parseInt(tokens[3]);
                if (!trainerMap.containsKey(trainerName)) {
                    Trainer trainer = new Trainer(trainerName);
                    trainerMap.put(trainerName, trainer);
                }
                trainerMap.get(trainerName).getPokemons().add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));
            }
            command = scan.nextLine();
        }
        String newCommand = scan.nextLine();
        while(!"End".equals(newCommand)){
            String element =newCommand;
            trainerMap.values().stream().forEach(trainer -> {
                if(trainer.hasPokemonWithGivenElement(element)){
                    trainer.increaseBadges();
                }else{
                    trainer.decreasePokemonsHealth();;
                    trainer.removeDiedPokemons();
                }
            });

            newCommand = scan.nextLine();
        }
        if(!trainerMap.isEmpty()) {
            trainerMap.values().stream().sorted((v1, v2) -> Integer.compare(v2.getBadges(),v1.getBadges())).forEach(v1 -> System.out.printf("%s %d %d\n", v1.getName(), v1.getBadges(), v1.getPokemons().size()));
        }
    }
}
