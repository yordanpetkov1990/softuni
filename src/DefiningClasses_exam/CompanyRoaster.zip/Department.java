package DefiningClasses_exam;

import java.util.ArrayList;
import java.util.List;

public class Department {
    private List<Employee> employeeList;
    private String name;

    public Department(List<Employee> employeeList,String name) {
        this.employeeList = employeeList;
        this.name = name;
    }
    public Department(String name){
        this.name = name;
        this.employeeList = new ArrayList<>();
    }
    public Department(){
        this.employeeList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Employee> getEmployeeList() {
        return employeeList;
    }


    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }
    public double getAverageSalaryOfDepartment(){
        double averagesalary = 0;
        for (Employee employee : getEmployeeList()) {
            averagesalary+=employee.getSalary();
        }
        averagesalary/=getEmployeeList().size();
        return averagesalary;
    }
}
