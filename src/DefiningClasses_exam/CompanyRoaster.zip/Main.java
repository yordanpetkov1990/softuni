package DefiningClasses_exam;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        List<Department> departmentList = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] tokens = scanner.nextLine().split("\\s+");
            Employee employee;
            Department department = new Department();
            String departmentName = tokens[3];
            if(tokens.length == 4){
                employee = new Employee(tokens[0],Double.parseDouble(tokens[1]),tokens[2],departmentName);
            }else if(tokens.length == 5){
                if(tokens[4].matches("[0-9]+")){
                    employee = new Employee(tokens[0],Double.parseDouble(tokens[1]),tokens[2],departmentName,Integer.parseInt(tokens[4]));
                }else{
                    employee = new Employee(tokens[0],Double.parseDouble(tokens[1]),tokens[2],departmentName,tokens[4]);
                }
            }
            else{
                employee = new Employee(tokens[0],Double.parseDouble(tokens[1]),tokens[2],departmentName,tokens[4],Integer.parseInt(tokens[5]));
            }
            department.setName(departmentName);
            department.getEmployeeList().add(employee);
            boolean isFound = false;
            for (Department department1 : departmentList) {
                if(department1.getName().equals(departmentName)){
                    department1.getEmployeeList().add(employee);
                    isFound= true;
                }
            }
            if(!isFound){
                departmentList.add(department);
            }
        }
        departmentList =departmentList.stream().sorted((d1, d2) -> Double.compare(d2.getAverageSalaryOfDepartment(),d1.getAverageSalaryOfDepartment())).collect(Collectors.toList());
        System.out.println();



    }
}
//            department.getEmployeeList().add(employee);
//            if(!departmentMap.containsKey(departmentName)){
//                departmentMap.put(departmentName,department);
//            }else{
//            department.getEmployeeList().add(employee);
//            if(!departmentMap.containsKey(departmentName)){
//                departmentMap.put(departmentName,department);
//            }else{
//                departmentMap.get(departmentName).getEmployeeList().add(employee);
//            }
//                departmentMap.get(departmentName).getEmployeeList().add(employee);
//        Department department = departmentMap.values().stream()
//                .sorted((d1, d2) -> {
//                    double averageSalary1 = d1.getEmployeeList().stream()
//                            .mapToDouble(Employee::getSalary)
//                            .average()
//                            .orElse(0);
//                    double averageSalary2 = d2.getEmployeeList().stream()
//                            .mapToDouble(Employee::getSalary)
//                            .average()
//                            .orElse(0);
//
//                    return Double.compare(averageSalary2, averageSalary1);
//                })
//                .findFirst()
//                .orElse(null);
//        System.out.println("Highest Average Salary: " + department.getName());
//       department.getEmployeeList().stream().sorted((e1,e2) -> Double.compare(e2.getSalary(), e1.getSalary())).forEach(e -> System.out.println(e.toString()) );
//            }
