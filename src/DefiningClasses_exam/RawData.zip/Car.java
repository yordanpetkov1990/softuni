package DefiningClasses_exam;

public class Car {
    private String model;
    private Engine engine;
    private Cargo cargo;
    private Tire[] arr;

    public Car(String model, Engine engine, Cargo cargo, Tire[] arr) {
        this.model = model;
        this.engine = engine;
        this.cargo = cargo;
        this.arr = arr;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Tire[] getArr() {
        return arr;
    }

    public void setArr(Tire[] arr) {
        this.arr = arr;
    }

    @Override
    public String toString() {
        return this.model;
    }
}
