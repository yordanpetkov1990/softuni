package DefiningClasses_exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        //"{Model} {EngineSpeed} {EnginePower} {CargoWeight} {CargoType} {
        // Tire1Pressure} {Tire1Age} {Tire2Pressure} {Tire2Age}
        // {Tire3Pressure} {Tire]’3Age} {Tire4Pressure} {Tire4Age}",
        List<Car> carList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String[] tokens = scan.nextLine().split("\\s+");
            String model = tokens[0];
            int engineSpeed = Integer.parseInt(tokens[1]);
            int enginePower = Integer.parseInt(tokens[2]);
            int cargoWeight = Integer.parseInt(tokens[3]);
            String cargoType = tokens[4];
            double tire1Pressure = Double.parseDouble(tokens[5]);
            double tire2Pressure = Double.parseDouble(tokens[7]);
            double tire3Pressure = Double.parseDouble(tokens[9]);
            double tire4Pressure = Double.parseDouble(tokens[11]);
            int tire1Age = Integer.parseInt(tokens[6]);
            int tire2Age = Integer.parseInt(tokens[8]);
            int tire3Age = Integer.parseInt(tokens[10]);
            int tire4Age = Integer.parseInt(tokens[12]);
            Car car = new Car(model,new Engine(),new Cargo(),new Tire[4]);
            car.getEngine().setPower(enginePower);
            car.getEngine().setSpeed(engineSpeed);
            car.getCargo().setType(cargoType);
            car.getCargo().setWeight(cargoWeight);
            car.getArr()[0] = new Tire();
            car.getArr()[1] = new Tire();
            car.getArr()[2] = new Tire();
            car.getArr()[3] = new Tire();
            car.getArr()[0].setAge(tire1Age);
            car.getArr()[0].setPressure(tire1Pressure);
            car.getArr()[1].setAge(tire2Age);
            car.getArr()[1].setPressure(tire2Pressure);
            car.getArr()[2].setAge(tire3Age);
            car.getArr()[2].setPressure(tire3Pressure);
            car.getArr()[3].setAge(tire4Age);
            car.getArr()[3].setPressure(tire4Pressure);
            carList.add(car);
        }
        String command = scan.nextLine();
        if(command.equals("fragile")){
            List<Car> fragile = carList.stream().filter(car -> car.getCargo().getType().equals("fragile")).collect(Collectors.toList());
            for (Car car : fragile) {
                for (Tire tire : car.getArr()) {
                    if(tire.getPressure() < 1){
                        System.out.println(car.toString());
                        break;
                    }
                }
            }
        }else if(command.equals("flamable")){
            carList.stream().filter(car -> car.getCargo().getType().equals("flamable") && car.getEngine().getPower() > 250).forEach(car -> System.out.println(car.toString()));

        }
    }
}
